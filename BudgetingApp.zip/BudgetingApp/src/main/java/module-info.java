module edu.miracosta.cs112.budgetingapp {
    requires javafx.controls;
    requires javafx.fxml;


    opens edu.miracosta.cs112.budgetingapp to javafx.fxml;
    exports edu.miracosta.cs112.budgetingapp;
}