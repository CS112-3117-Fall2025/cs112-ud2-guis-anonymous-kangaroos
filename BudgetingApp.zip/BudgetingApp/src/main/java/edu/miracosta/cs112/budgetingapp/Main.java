package edu.miracosta.cs112.budgetingapp;//package name here depending on your IDE

import javafx.application.Application;  //abstract class used for JavaFX GUI's
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.HBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;              //class for GUI window
import javafx.scene.Scene;              //class for specific view in GUI window
import javafx.scene.layout.VBox;        //class for layout pane, organized top-to-bottom
import javafx.scene.control.Button;     //class for button component
import javafx.event.EventHandler;       //interface for handling events
import javafx.event.ActionEvent;        //class for type of event for action (like button or key pressed)
import javafx.geometry.Pos; //for aligning vbox elements
import java.io.File;
//import libraries for file IO:
import java.io.FileNotFoundException;
//import for date formatting
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
//import for reading files
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
//for alerts on invalid file selections
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;


public class Main extends Application implements EventHandler<ActionEvent> { //inheriting core functionality + this class will handle events
    public static final String bgColor = "-fx-background-color: #F3F4F6;";
    public static final String textColor = "-fx-text-fill: #111827;";
    public static final int NUM_COLUMNS = 3;
    /*** GUI COMPONENTS ***/
    private Button button;
    private FileChooser file;
    //create scanner object for file IO
    BufferedReader inputStream = null;
    String[] lines;
    String[] allData;
    //create array of date objects to store dates from file
    Date[] dates;
    //create array to hold spending values
    double[] spending;
    String[] categories;
    //create array to hold data labels
    String temp = null;

    /*** DRIVER main ***/
    public static void main(String[] args) {
        launch(args); //method from Application class, must be called to setup javafx application
    }

    /*** OVERRIDDEN Application METHODS ***/
    @Override
    public void start(Stage primaryStage) throws Exception { //Application automatically calls this method to run (our) main javafx code. passes in primary stage (main window)
        //create vbox using 20 px for vertical spacing
        VBox vBox = new VBox(20);
        vBox.setStyle(bgColor);
        // Set the alignment of the VBox's children to CENTER
        vBox.setAlignment(Pos.TOP_CENTER);

        //create icon object
        Image appIcon = new Image(getClass().getResourceAsStream("/images/MoneyIcon.png"));
        //set title and icon for primary stage
        primaryStage.setTitle("JavaBudget");
        primaryStage.getIcons().add(appIcon);

        //create a label to display instructions to user
        Label instructions = new Label("Select a text file to input spending data!");
        instructions.setStyle(textColor);

        //create textfield for file path
        TextField filePathBox = new TextField();
        filePathBox.setPrefWidth(400);
        filePathBox.setStyle("-fx-background-color: #FFFFFF;" + textColor);

        //create label for displaying spending breakdown after file upload
        //create header label
        Label spendingBreakdown = new Label();
        //style header
        spendingBreakdown.setStyle(textColor);

        //create file browser button
        Button button = new Button("Browse");
        //set style for button
        button.setStyle("-fx-background-color: #3B82F6;" + textColor);


        //set height of text box to height of button
        filePathBox.setPrefHeight(button.getHeight());

        // Create an HBox to hold the Label and Button horizontally
        HBox fileIO = new HBox(10); // 10 pixels spacing between elements
        fileIO.setAlignment(Pos.CENTER); // Align content within HBox
        fileIO.getChildren().addAll(filePathBox, button);

        //create header label
        Label headerLabel = new Label("JavaBudget");
        //style header
        headerLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-padding: 10;" + textColor);
        // Add the children to the VBox
        vBox.getChildren().addAll(headerLabel, instructions, fileIO);

        Scene scene = new Scene(vBox, 960, 600);

        primaryStage.setScene(scene);
        primaryStage.show();
        //file browser button event handler
        button.setOnAction(e -> {
            //create file browser object
            file = new FileChooser();
            file.setTitle("Open Budgeting File (.txt format)");
            file.getExtensionFilters().addAll(
                    //specify valid file extension (txt only)
                    new FileChooser.ExtensionFilter("Text Files", "*.txt")
            );
            //set file to one selected in file browser
            File selectedFile = file.showOpenDialog(primaryStage);

            //set filepath box to selected file
            filePathBox.setText(String.valueOf(selectedFile.getAbsoluteFile()));
            //parse data from file
            try {
                parseData(readFile(selectedFile));
            }
            catch (IllegalArgumentException iae) {
                //dont process data
            }
            catch (FileNotFoundException fnfe) {
                //String title, String header, String content
                showWarningAlert("Warning","File Not Found", "Please select a different file!");
            }
            catch (IOException ioe) {
                showWarningAlert("Warning","Failed to open file.", "Please select a different file!");
            }
            //create pieChart object & instantiate based off parsed file data using full constructor
            PieChart pieChart = new PieChart("Spending Breakdown", spending, categories, new Legend());
            //set text of spending breakdown to piechart class output
            spendingBreakdown.setText(pieChart.printChart());
            vBox.getChildren().add(spendingBreakdown);
        });

    }

    /*** OVERRIDDEN EventHandler METHODS ***/
    @Override
    public void handle(ActionEvent actionEvent) { //generic method used to handle when events occur (like handle button click)
        //good practice to identify source, in case you have multiple event types/sources
        if (actionEvent.getSource() == button) {
            //action on click
        }
    }

    public String[] readFile(File file) throws IllegalArgumentException, IOException {
        if (file == null) {
            throw new IllegalArgumentException("File cannot be null");
        }
        StringBuilder sb = new StringBuilder();
        try (BufferedReader inputStream = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = inputStream.readLine()) != null) {
                    sb.append(line).append("\n"); // add newline to preserve structure
                }
        } catch (FileNotFoundException fnfe) {
            throw new FileNotFoundException("File cannot be found");
        } catch (IOException ioe) {
            throw new IOException("File cannot be opened");
        }
        //manipulation of data received from file:
        //split by new line or comma
        String[] lines = sb.toString().split("[,\\n\\r]+");
        return lines;
    }

    public void parseData(String[] data) throws IllegalArgumentException {
        boolean validData = true;
        //calc array size for date array
        int numRows = data.length / NUM_COLUMNS;
        //instantiate array sizes with proper lengths for given data set
        dates = new Date[numRows];
        spending = new double[numRows];
        categories = new String[numRows];

        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

        for (int row = 0; row < numRows; row++) {
            int baseIndex = row * NUM_COLUMNS;
            try {
                dates[row] = formatter.parse(data[baseIndex]);              // first column = date
                spending[row] = Double.parseDouble(data[baseIndex + 1]);   // second column = spending
                categories[row] = data[baseIndex + 2];                     // third column = category
            } catch (ParseException | NumberFormatException e) {
                throw new IllegalArgumentException("Invalid data format in text file!");
            }
        }
    }

    //create warning method for user errors
    public static void showWarningAlert(String title, String header, String content) {
        Alert alert = new Alert(AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
