[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=20906158)
# UD1 - OOP + UML Description

<br><br>
This project is a budgeting app. Once Main.java is developed, the user will upload files with their financial information and the driver will parse that data and display the user's finances in graphical form. The 3 graph types developed thus far are parsed into 3 distinct classes: PieChart, BarGraph, and LineGraph. Each class is derived from the abstract parent class Chart. Legend class is bare bones but functional. It was included to not throw errors when BarGraph and PieChart classes are tested because both use Legend instance variables.

<br><br>

# Group Members
<br><br>
Isabella Watson, Nick Henao, Asan
<br><br>

## Project Requirements\*
<br><br>
<b>Included:</b> 4 concrete classes (PieChart, LineGraph, BarGraph, Legend), 3 tester clases (PieChartTester, LineGraphTester, BarGraphTester), 1 abstract class (Graph), inheritance/polymorphism, custom exception class (MismatchedDataLengthException)
<br><br>
<b> Not Included: </b> Inner Class
An inner class was not included here because it does not make sense. None of the chart types are logically ties to each other. They are all child classes of the abstract class Graph.java. They exist independently and dont depend on the state of other classes.
<br><br>


## UML
![alt text](edu/miracosta/cs112/budgetingapp/MoneyIcon.png)